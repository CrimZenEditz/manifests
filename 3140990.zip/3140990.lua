-- Fetch from public repos for AppID: 3140990
-- Game: Backrooms Cleanup Crew
addappid(3140990)
addappid(3140991, 1, "d81e674b226c7ab087cff2aedcf107268b8d53a6264227b549fe9b4a0ae7c35f")

-- Set Manifest GIDs
setManifestid(3140991, "7330495238387290050", 0)