addappid(2233120)
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(2233121,0,"908cc3ca235e2d744c3f800596e90f596fe3b9acd68a130ec56985fbdf262212")
setManifestid(2233121,"9154476076427286724")


--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]