-- Fetch from public repos for AppID: 2616140
-- Game: Sunset Motel
addappid(2616140)
addappid(2616141, 1, "ef52715a1a30dd7b951c862bae4ab7c50394aef7a3635d8ba058e97db3873dbc")

-- Set Manifest GIDs
setManifestid(2616141, "660077157210307943", 0)