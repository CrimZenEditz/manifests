addappid(1164940)
addappid(1164944, 1, "e7cf384fd9cc9adec7e85fe5751ed3bb5fe89e2cf1c3c1135df0dbd421580c3c")
setManifestid(1164944, "2586365741953940983", 0)


addappid(2615910) -- Trepang2 - Survival Mode DLC
addappid(2615920) -- Trepang2 - Bladekisser DLC
addappid(2656880) -- Trepang2 - Season Pass
