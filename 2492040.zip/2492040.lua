addappid(2492040)
addappid(3141970)
addappid(2492041,0,"22de4afa6bcad3761cbb58d3ba24b93045b264b33a9bf659ac64b3782375e691")
setManifestid(2492041,"5873254584822683634")


--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]