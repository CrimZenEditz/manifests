addappid(42680)
addappid(42681,0,"b7003c5ea7e370881499daaf5ba52ea4f3a1e76843fb37ab4d97753d94df8f95")
setManifestid(42681,"5651167211650965131")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
