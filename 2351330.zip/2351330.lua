addappid(2351330)
addappid(2351331,0,"63e0be979e19e309eb7ef366a4ac02a404ce3972054b256a8de46bee9824ee1a")
setManifestid(2351331,"224270652003646552")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]